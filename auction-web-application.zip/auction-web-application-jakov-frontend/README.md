# auction-web-application
Emmanuel Simon Learmont - User authentication, registration, and login on Django
Ali Abbas Naqvi - Back end api calls and modelling on Django and Vue
Jakov Natanel Petrovic - Front end formatting and vue router functionality
Varnika Vaid - Nothing

# users
test1
test2
test3
test4
test5

## password (same for all)
django123